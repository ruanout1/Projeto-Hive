// ===================================
// 1. CARREGAR VARIÁVEIS DE AMBIENTE
// ===================================
require('dotenv').config();

const express = require("express");
const cors = require("cors");
const path = require("path");

// =============================================
// 2. IMPORTAÇÃO DAS ROTAS
// =============================================

// --- ROTAS ADMINISTRATIVAS (Versão da colega) ---
const clientRoutes = require('./routes/clientRoutes');
const scheduleRoutes = require('./routes/scheduleRoutes');
const timeClockRoutes = require('./routes/timeClockRoutes');
const serviceRequestRoutes = require('./routes/serviceRequestRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const teamRoutes = require('./routes/teamRoutes');
const userRoutes = require('./routes/userRoutes');
const serviceCatalogRoutes = require('./routes/serviceCatalogRoutes');
const collaboratorAllocationRoutes = require('./routes/collaboratorAllocationRoutes');
const authRoutes = require('./routes/authRoutes');
const clientScheduledRoutes = require('./routes/clientScheduledRoutes');

// --- ROTAS EXTRAS (Suas rotas) ---
const clientPortalRoutes = require('./routes/clientPortalRoutes');
const managerRoutes = require('./routes/managerRoutes');
const communicationRoutes = require('./routes/communicationRoutes');

// =============================================
// 3. REGISTRAR ASSOCIAÇÕES DO BANCO DE DADOS
// =============================================
const { setupAssociations } = require('./database/associations');
setupAssociations();

// =============================================
// 4. CONFIGURAR APLICAÇÃO EXPRESS
// =============================================
const app = express();

// =============================================
// 5. CONFIGURAR CORS
// =============================================
const corsOptions = {
  origin: [
    "http://localhost:3000",
    "http://localhost:5173"
  ],
  methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  credentials: true, // Permite envio de cookies/headers
};

app.use(cors(corsOptions));

// =============================================
// 6. MIDDLEWARES GLOBAIS
// =============================================
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));
app.use("/src", express.static(path.join(__dirname, "src")));

// =============================================
// 7. REGISTRO DAS ROTAS DA API
// =============================================

// --- AUTENTICAÇÃO ---
app.use('/api/auth', authRoutes);

// --- GESTÃO ADMINISTRATIVA (Admin/Manager) ---
app.use('/api/clients', clientRoutes);                           // CRUD de clientes
app.use('/api/schedule', scheduleRoutes);                        // Agendamentos
app.use('/api/time-clock', timeClockRoutes);                     // Ponto eletrônico
app.use('/api/service-requests', serviceRequestRoutes);          // Solicitações de serviço
app.use('/api/dashboard', dashboardRoutes);                      // Dashboard admin
app.use('/api/teams', teamRoutes);                               // Equipes
app.use('/api/users', userRoutes);                               // Usuários
app.use('/api/service-catalog', serviceCatalogRoutes);           // Catálogo de serviços
app.use('/api/allocations', collaboratorAllocationRoutes);       // Alocação de colaboradores
app.use('/api/client-portal', clientScheduledRoutes);            // Serviços agendados 

// --- PORTAL DO CLIENTE (Cliente visualiza seus dados) ---
app.use('/api/client-portal', clientPortalRoutes);               // Portal do cliente

// --- ROTAS DE GESTORES E COMUNICAÇÃO ---
app.use('/api/manager', managerRoutes);                          // Funcionalidades de gestores
app.use('/api/communication', communicationRoutes);              // Sistema de comunicação

// =============================================
// 8. ROTA DE HEALTH CHECK
// =============================================
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    message: 'Backend Hive funcionando corretamente',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    routes: {
      auth: '/api/auth',
      clients: '/api/clients (Admin/Manager)',
      clientPortal: '/api/client-portal (Client)',
      teams: '/api/teams',
      users: '/api/users',
      manager: '/api/manager',
      communication: '/api/communication'
    }
  });
});

// =============================================
// 9. TRATAMENTO DE ROTAS NÃO ENCONTRADAS
// =============================================
app.use((req, res) => {
  res.status(404).json({
    error: 'Rota não encontrada',
    path: req.path,
    method: req.method,
    message: 'Verifique a documentação da API'
  });
});

// =============================================
// 10. TRATAMENTO DE ERROS GLOBAL
// =============================================
app.use((err, req, res, next) => {
  console.error('❌ Erro no servidor:', err);
  
  res.status(err.status || 500).json({
    error: 'Erro interno do servidor',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Algo deu errado',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// =============================================
// 11. INICIAR SERVIDOR
// =============================================
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log("\n====================================");
  console.log(`🚀 Servidor Hive rodando na porta ${PORT}`);
  console.log(`🌍 Ambiente: ${process.env.NODE_ENV || 'development'}`);
  console.log("====================================");
  console.log("\n📍 Rotas disponíveis:");
  console.log(`   • Health Check:     http://localhost:${PORT}/api/health`);
  console.log(`   • Autenticação:     http://localhost:${PORT}/api/auth`);
  console.log(`   • Admin/Manager:    http://localhost:${PORT}/api/clients`);
  console.log(`   • Portal Cliente:   http://localhost:${PORT}/api/client-portal`);
  console.log(`   • Equipes:          http://localhost:${PORT}/api/teams`);
  console.log(`   • Usuários:         http://localhost:${PORT}/api/users`);
  console.log(`   • Gestores:         http://localhost:${PORT}/api/manager`);
  console.log(`   • Comunicação:      http://localhost:${PORT}/api/communication`);
  console.log("\n✅ Arquitetura de rotas por Recurso está ATIVA");
  console.log("====================================\n");
});

module.exports = app;
