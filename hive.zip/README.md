
  # Hive

 Empresas que terceirizam colaboradores (vigilantes, porteiros, serviços gerais, zeladores, Facilities) enfrentam desafios de gestão de equipes, comunicação, escalas de trabalho e acompanhamento de serviços.
O Hive surge como uma solução tecnológica que centraliza essas operações em um ecossistema digital, inspirado no funcionamento de uma colmeia, onde cada membro trabalha de forma organizada para o bem coletivo, com um ponto de gestão central semelhante à abelha rainha.
A escolha do nome reforça a ideia de organização coletiva, produtividade e colaboração.


  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
